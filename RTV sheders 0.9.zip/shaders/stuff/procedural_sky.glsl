/*---------------------------------------------------------------------
    RTV procedural sky
    Analytic day / sunset / night sky: zenith-to-horizon gradient, warm band toward the sun at twilight
    (and a faint pink belt on the opposite side), sun and moon glow, hazy horizon.
    dir, sun_dir: world space, normalized. Returns a colour in the same sRGB-like range the vanilla sky uses.
---------------------------------------------------------------------*/
#ifndef RTV_PROCEDURAL_SKY_GLSL
#define RTV_PROCEDURAL_SKY_GLSL

vec3 rtv_procedural_sky(in vec3 dir, in vec3 sun_dir)
{
    float sh = sun_dir.y;                     // sun elevation: -1 (below) .. +1 (zenith)
    float v = dir.y;
    float day = smoothstep(-0.14, 0.30, sh);
    float twi = exp(-pow(sh * 3.2, 2.0)) * smoothstep(-0.32, -0.08, sh);   // strongest when the sun is at the horizon

    vec3 zen = mix(vec3(0.006, 0.010, 0.035), vec3(0.14, 0.34, 0.80), day);
    vec3 hor = mix(vec3(0.025, 0.035, 0.085), vec3(0.60, 0.76, 0.95), day);
    zen = mix(zen, vec3(0.20, 0.24, 0.52), twi * 0.65);
    hor = mix(hor, vec3(0.75, 0.52, 0.52), twi * 0.55);

    float h = pow(1.0 - clamp(v, 0.0, 1.0), 2.6);          // 1 at the horizon, 0 overhead
    vec3 sky = mix(zen, hor, h);

    // sunrise / sunset colours: orange toward the sun, a soft pink-violet belt on the other side
    vec2 az = normalize(dir.xz + vec2(1e-4));
    vec2 saz = normalize(sun_dir.xz + vec2(1e-4));
    float toward = pow(max(dot(az, saz), 0.0), 2.5);
    sky = mix(sky, vec3(1.00, 0.48, 0.18), clamp(twi * h * toward * 1.1, 0.0, 1.0));
    sky = mix(sky, vec3(0.80, 0.42, 0.62), clamp(twi * h * (1.0 - toward) * 0.35, 0.0, 1.0));

    // sun glow (the sun disc itself is drawn by the game)
    float cs = max(dot(dir, sun_dir), 0.0);
    float glow = pow(cs, 8.0) * 0.22 + pow(cs, 64.0) * 0.55;
    // Use the v0.7 sun temperature: neutral at noon and gently warm near sunrise/sunset.
    sky += rtv_sun_color() * glow * smoothstep(-0.10, 0.15, sh) * (0.55 + 0.45 * twi);

    // moon glow
    vec3 moon = -sun_dir;
    float cm = max(dot(dir, moon), 0.0);
    // A restrained cool moon halo, avoiding an overly blue global cast.
    sky += vec3(0.62, 0.72, 0.94) * (pow(cm, 24.0) * 0.12 + pow(cm, 200.0) * 0.18) * (1.0 - day) * smoothstep(-0.12, 0.10, moon.y);

    // below the horizon: dark haze, never a hard edge
    sky = mix(sky, hor * 0.65, smoothstep(0.0, -0.22, v));
    return max(sky, vec3(0.0));
}

#endif
