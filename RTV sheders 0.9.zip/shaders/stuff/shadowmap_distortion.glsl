// Classic Minecraft shadow map.  Keeping the projection linear makes the
// caster direction and shape stable instead of using the BSL/Complementary
// radial distortion look.  This file is shared by shadow rendering and lookup.

// Originally ported from : https://github.com/shaderLABS/Shadow-Tutorial  (Thank you null)

#define SHADOW_DISTORT_FACTOR 0.18 //Retained for compatible saved options; linear projection does not use it. [0.04 0.06 0.08 0.10 0.12 0.15 0.18 0.20 0.25 0.30 0.40 0.50]
#define SHADOW_BIAS 0.75 //Balanced for the linear map: less detached/peter-panned shadow while retaining slope bias. [0.00 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.75 0.80 0.90 1.00 1.50 2.00 2.50 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00]
#define NORMAL_BIAS //Offsets the shadow sample position along the surface normal (standard anti-acne technique)
#define EXCLUDE_FOLIAGE //If true, foliage will not cast shadows.

// How far (blocks) the sun shadow map reaches. Beyond it there are no shadows, so keep it at least as far as your render distance.
const float shadowDistance = 512.0; //[96.0 128.0 160.0 192.0 224.0 256.0 320.0 384.0 448.0 512.0 640.0 768.0]
const int shadowMapResolution = 4096; //Long-range default; higher resolutions preserve more shadow detail at distance. [128 256 512 1024 2048 4096 8192]

// Depth of the shadow map is squashed by this factor so tall casters outside the view are not clipped.
#define SHADOW_Z_SCALE 0.5

#ifdef SHADOW_DISTORT_ENABLED
	// Optional compatibility path only; disabled by default above.
	vec3 distort(vec3 pos) {
		float factor = (length(pos.xy) + SHADOW_DISTORT_FACTOR) / (1.0 + SHADOW_DISTORT_FACTOR);
		return vec3(pos.xy / factor, pos.z * SHADOW_Z_SCALE);
	}
#else
	vec3 distort(vec3 pos) {
		return vec3(pos.xy, pos.z * SHADOW_Z_SCALE);
	}
#endif
