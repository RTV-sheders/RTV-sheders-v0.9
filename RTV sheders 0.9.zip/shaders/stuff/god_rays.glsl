/*---------------------------------------------------------------------
    RTV soft god rays (occluder-attached)
    ------------------------------------------------------------------
    Ray march from the camera to the surface (or GOD_RAYS_DISTANCE for sky pixels), reading the sun shadow map.

    A sample only scatters light when
      1. it is lit by the sun (the beam itself), AND
      2. some of its neighbours, a few blocks to the side and at the SAME light depth, are in shadow.

    Condition 2 is what ties the shafts to trees, leaves and buildings: in open air, far from any occluder, every
    neighbour is lit, the gate is zero and nothing is drawn. Right beside a trunk, under a canopy, in a window or
    in a narrow gap between two walls, part of the neighbourhood is shadowed and a soft shaft appears.

    Colour is a warm gold that follows the sun (more amber near the horizon). Energy is compressed with 1 - exp(-x)
    and hard capped, so shafts stay thin and never turn into a thick white fog.

    Needs: shadowtex1, shadowProjection / shadowModelView (space_transforms.glsl), SUN_BRIGHTNESS and the day helpers
    in settings.glsl, and the Iris uniform `wetness` (declared by volumetric_clouds.glsl or below).
---------------------------------------------------------------------*/

#ifndef RTV_GOD_RAYS_GLSL
#define RTV_GOD_RAYS_GLSL

#if GOD_RAYS == 1

#if CLOUD_STYLE != 1
uniform float wetness;
#endif

// Henyey-Greenstein normalised to 1.0 when looking straight at the sun.
float rtv_gr_phase(float c, float g)
{
    float hg  = (1.0 - g * g) / pow(1.0 + g * g - 2.0 * g * c, 1.5);
    float hg1 = (1.0 + g) / ((1.0 - g) * (1.0 - g));
    return hg / hg1;
}

// Shared HDR shaft integration. A low-discrepancy disk keeps neighbouring pixels
// from receiving unrelated random tap layouts (the old pattern read as bright dots).
vec3 rtv_god_rays_integrate(in vec3 view_dir, in float surface_dist, in vec3 sun_dir,
                            in float jitter, in float jitter2, in bool underwater)
{
    float day = smoothstep(0.0, 0.12, max(rtv_day_cycle(), 0.0));
    float sun_up = smoothstep(0.015, 0.16, sun_dir.y);
    float weather = 1.0 - smoothstep(0.05, 0.60, clamp(wetness, 0.0, 1.0));
    float strength = underwater ? UNDERWATER_GOD_RAYS_STRENGTH : GOD_RAYS_STRENGTH;
    float gate = day * sun_up * weather * strength;
    if (gate < 0.002) return vec3(0.0);

    float max_distance = underwater ? float(UNDERWATER_GOD_RAYS_DISTANCE) : float(GOD_RAYS_DISTANCE);
    float t_end = min(surface_dist, max_distance);
    const float t_start = 0.6;
    if (t_end <= t_start + 0.5) return vec3(0.0);

    vec2 uv_per_block = vec2(abs(shadowProjection[0][0]), abs(shadowProjection[1][1])) * 0.5;
    float z_bias = 0.08 * 0.5 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]);

    const int TAPS = GOD_RAYS_TAPS;
    vec2 tap_off[GOD_RAYS_TAPS];
    // Sunflower / golden-angle disk: evenly covers the neighbourhood. Only a tiny
    // stable rotation remains, so the pattern does not become visible as a grid.
    float tap_rotation = (jitter2 - 0.5) * 0.12;
    for (int k = 0; k < TAPS; k++)
    {
        float a = float(k) * 2.399963 + tap_rotation;
        float r = sqrt((float(k) + 0.5) / float(TAPS)) * GOD_RAYS_REACH;
        tap_off[k] = vec2(cos(a), sin(a)) * r * uv_per_block;
    }

    const int STEPS = GOD_RAYS_STEPS;
    float span = t_end - t_start;
    float inv_n = 1.0 / float(STEPS);
    float accum = 0.0;

    for (int i = 0; i < STEPS; i++)
    {
        float su0 = (float(i) + jitter) * inv_n;
        float su1 = (float(i) + 1.0 + jitter) * inv_n;
        float t = t_start + span * su0 * su0;
        float dt = span * (su1 * su1 - su0 * su0);

        vec3 p = view_dir * t;
        vec3 sp = foot_pos_to_shadowmap_texcoord(p);
        if (sp.x < 0.02 || sp.x > 0.98 || sp.y < 0.02 || sp.y > 0.98) continue;
        float z = sp.z - z_bias;
        float lit = step(z, texture(shadowtex1, sp.xy).r);
        if (lit < 0.5) continue;

        float occ = 0.0;
        for (int k = 0; k < TAPS; k++)
        {
            vec2 q = clamp(sp.xy + tap_off[k], vec2(0.001), vec2(0.999));
            occ += 1.0 - step(z, texture(shadowtex1, q).r);
        }
        occ /= float(TAPS);
        // A higher threshold suppresses isolated one-tap hits, which were the
        // main source of the dotted appearance around leaves and distant edges.
        float near_occluder = smoothstep(0.14, 0.78, occ);

        float density = exp(-max(p.y, 0.0) * 0.010) * exp(-t * (underwater ? 0.014 : 0.0105));
        if (underwater)
        {
            // Underwater keeps a little open-water scattering, but shadow edges
            // provide the visible shaft structure. Water absorption limits range.
            accum += lit * (0.20 + 0.80 * near_occluder) * density * dt;
        }
        else
        {
            accum += near_occluder * density * dt;
        }
    }

    float cos_sun = dot(view_dir, sun_dir);
    if (underwater)
    {
        float phase = 0.18 + 0.82 * rtv_gr_phase(cos_sun, 0.72);
        float amount = 1.0 - exp(-accum * UNDERWATER_GOD_RAYS_DENSITY * phase);
        amount = min(amount, 0.34);
        float low_sun = 1.0 - smoothstep(0.10, 0.60, sun_dir.y);
        vec3 water_beam = mix(vec3(0.30, 0.66, 0.94), vec3(0.48, 0.72, 0.88), low_sun * 0.45);
        return water_beam * (amount * gate * SUN_BRIGHTNESS * 0.075 * rtv_sky_illumination_factor());
    }

    float phase = 0.30 + 0.70 * rtv_gr_phase(cos_sun, 0.55);
    float low_sun = 1.0 - smoothstep(0.10, 0.60, sun_dir.y);
    vec3 warm = mix(vec3(1.00, 0.85, 0.62), vec3(1.00, 0.66, 0.36), low_sun);
    warm *= rtv_sun_color();
    float amount = 1.0 - exp(-accum * GOD_RAYS_DENSITY * phase);
    amount = min(amount, 0.48);
    return warm * (amount * gate * SUN_BRIGHTNESS * 0.18 * rtv_sky_illumination_factor());
}

// Above-water shafts: light scattered beside leaves, trees and structures.
vec3 rtv_god_rays(in vec3 view_dir, in float surface_dist, in vec3 sun_dir, in float jitter, in float jitter2)
{
    return rtv_god_rays_integrate(view_dir, surface_dist, sun_dir, jitter, jitter2, false);
}

// Underwater shafts: cool sunlight scattered through the water volume, with
// shadow-edge contrast and a short Beer-Lambert range to avoid a flat blue fog.
vec3 rtv_underwater_god_rays(in vec3 view_dir, in float surface_dist, in vec3 sun_dir, in float jitter, in float jitter2)
{
    #if UNDERWATER_GOD_RAYS == 1
        return rtv_god_rays_integrate(view_dir, surface_dist, sun_dir, jitter, jitter2, true);
    #else
        return vec3(0.0);
    #endif
}

#endif // GOD_RAYS

#endif
