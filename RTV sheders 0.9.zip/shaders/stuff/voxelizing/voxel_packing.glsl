// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2025 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

// Purpose:
	// Pack and Unpack PBR Data densely into a Voxel Scene

// Packing Functions
#if PACKING_VOXELS_HERE == 1
uint pack_voxel_with_dense_PBR()
{
	//scene information packed in 32 bits, this can be whatever you want!
	
	// I am going to densely pack an entire PBR implementation into 32 bits!
	
	// since this is complicated we will probably want unpacking functions
	
	uint integerValue = 0u;
	//Vanilla lighting
		//4 bits counts to 16
		
		//lightmap
		uint bit_data = uint(lmcoord.x *15.9);//fit 0 to 1.0 into 0u to 15u (4 bits)
		integerValue = bitfieldInsert(integerValue, bit_data, 0, 4);
		//4 of 32 bits used
		bit_data = uint(lmcoord.y *15.9);//fit 0 to 1.0 into 0u to 15u (4 bits)
		integerValue = bitfieldInsert(integerValue, bit_data, 4, 4);
		//8 of 32 bits used

		// let's use less bits here: 
		// 2 bits has 4 options, or 0 1 2 3
		// 3 bits is 8 options, or 0 1 2 3 4 5 6 7 
	
	//PBR			
		vec4 specular_texture = textureLod(specular, texcoord, log2(float(textureSize(gtexture, 0).x )));
		specular_texture.a = fract(specular_texture.a);
	//emission
		bit_data = uint(max(at_midBlock.w/15.,specular_texture.a) * 7.9);//fit 0 to 1.0 into 0u to 7u (3 bits)
		integerValue = bitfieldInsert(integerValue, bit_data, 8, 3);
		//11 of 32 bits used
 
	//shiny	and smooth
		float shiny = mc_Entity.x == 2 ? 1. : specular_texture.g * specular_texture.r;
		// Ice is glossy but remains dielectric, not metallic.
		if (mc_Entity.x == 4) shiny = max(shiny, 0.52);
		bit_data = uint(shiny * 7.9);
		integerValue = bitfieldInsert(integerValue, bit_data, 11, 3);
		//14 of 32 bits used
		
		// 32 - 14 is 18 bits left
		// 18 / 3 for RGB is 5 with 3 left
		// so we can pack 5 bit RGB & something else
		// 5 bits is 32 options

	// visualize color average
		vec4 albedo_tex = textureLod(gtexture, texcoord,log2(float(textureSize(gtexture, 0).x)));
		albedo_tex.rgb*= glcolor.rgb;
		if (mc_Entity.x == 4)
		{
			// Natural deep-blue ice tint, with just enough transmission to activate refraction.
			albedo_tex.rgb = mix(albedo_tex.rgb, vec3(0.015, 0.070, 0.18), 0.48);
			albedo_tex.a = min(albedo_tex.a, 0.94);
		}
		ivec3 rgb_bit_data = ivec3(albedo_tex.rgb * 31.9);//fit 0 to 1.0 into 0u to 7u (3 bits)
		integerValue = bitfieldInsert(integerValue, rgb_bit_data.r, 14, 5);
		integerValue = bitfieldInsert(integerValue, rgb_bit_data.g, 19, 5);
		integerValue = bitfieldInsert(integerValue, rgb_bit_data.b, 24, 5);

		//29 of 32 bits used, 3 left, lets add a mask or block id for special masks or materials
	
	//voxel material id
		// 3 bits gives us 8 options, we could rearrange things if we want more
		#if IS_AN_ENTITY == 1
			// mobs are designated as 5u
			bit_data = 5u;
		#else
			uint material_id = uint(mc_Entity.x);
			bit_data = 
				material_id == 1 ? 1u //water
				: material_id == 2 || (shiny > .6 && specular_texture.g > 230.5/255.) ? 2u //metals - hard and shiny
				: material_id == 3 ? 3u // glass
				: material_id == 4 ? 4u // reflective, cool-tinted ice
                : material_id == 6 ? 6u // mapped leaves / foliage: preserve cutout transmission behaviour
				: renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT ? 3u // other translucent blocks that tint light
	            : renderStage == MC_RENDER_STAGE_ENTITIES ? 5u //mobs are 5u
                : abs(length(at_midBlock.xyz)-55.) > .5  || albedo_tex.a < .9 ? 6u //other partial blocks that block some light but not all
				:0u; //standard
			
		#endif
						
		integerValue = bitfieldInsert(integerValue, bit_data, 29, 3);
		//32 of 32 bits used = Yay!   

	return integerValue;

}
#endif


// Unpacking Functions

vec2 unpack_lightmap_from_voxel(in uint i)
{
	return vec2( bitfieldExtract(i,0,4) ,  bitfieldExtract(i,4,4) ) / 15.;
}

vec4 unpack_pbr_from_voxel(in uint i)
{
	//doesn't include ipbr from voxel material flags
	return vec4( 
		vec2( bitfieldExtract(i,11,3) ) , //smooth and shiny
		0. , //sss
		bitfieldExtract(i,8,3) //emission
	) / 7.;
}

vec3 unpack_albedo_from_voxel(in uint i)
{
	return vec3(
		 bitfieldExtract(i,14,5),
		 bitfieldExtract(i,19,5),
		 bitfieldExtract(i,24,5)
	) / 31.;
}

uint unpack_material_flag_from_voxel(in uint i)
{
	return bitfieldExtract(i,29,3);
}
