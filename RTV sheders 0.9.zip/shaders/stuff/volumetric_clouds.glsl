/*---------------------------------------------------------------------
    RTV volumetric clouds (procedural cumulus)
    ------------------------------------------------------------------
    Ray marched slab of clouds between CLOUD_HEIGHT and CLOUD_HEIGHT + CLOUD_THICKNESS
    (world Y). Only drawn for sky pixels; vanilla clouds are switched off in
    shaders.properties when CLOUD_STYLE == 1. No textures needed, the shape comes
    from hash based value noise.

    returns: rgb = in-scattered cloud light (already in the HDR units of the sky),
             a   = how much of the sky behind is still visible (transmittance)
---------------------------------------------------------------------*/

#ifndef RTV_VOLUMETRIC_CLOUDS_GLSL
#define RTV_VOLUMETRIC_CLOUDS_GLSL

#ifndef RTV_FRAMETIME_DECLARED
uniform float frameTimeCounter;
#define RTV_FRAMETIME_DECLARED 1
#endif
// Iris/OptiFine weather uniform: smoothly rises while rain or a storm is active.
uniform float wetness;

float rtv_storm_factor()
{
    return smoothstep(0.025, 0.88, clamp(wetness, 0.0, 1.0));
}

float rtv_cloud_storm_offset()
{
    // A bounded, smoothly blended front offset moves the cloud field into place
    // as wetness rises, without a sudden time-scaled position jump.
    return rtv_storm_factor() * 180.0;
}

#if RTV_PHONE == 1
    #define CLOUD_STEPS_USED 16
    #define CLOUD_LIGHT_STEPS 3
#else
    #if CLOUD_QUALITY == 1
        #define CLOUD_STEPS_USED 28
    #elif CLOUD_QUALITY == 2
        #define CLOUD_STEPS_USED 40
    #else
        #define CLOUD_STEPS_USED 64
    #endif
    #define CLOUD_LIGHT_STEPS 5
#endif

float rtv_cloud_hash13(vec3 p)
{
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

float rtv_cloud_vnoise(vec3 p)
{
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = rtv_cloud_hash13(i);
    float n100 = rtv_cloud_hash13(i + vec3(1.0, 0.0, 0.0));
    float n010 = rtv_cloud_hash13(i + vec3(0.0, 1.0, 0.0));
    float n110 = rtv_cloud_hash13(i + vec3(1.0, 1.0, 0.0));
    float n001 = rtv_cloud_hash13(i + vec3(0.0, 0.0, 1.0));
    float n101 = rtv_cloud_hash13(i + vec3(1.0, 0.0, 1.0));
    float n011 = rtv_cloud_hash13(i + vec3(0.0, 1.0, 1.0));
    float n111 = rtv_cloud_hash13(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
               mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y), f.z);
}

// ---------------------------------------------------------------------
// Slowly changing "weather": cloud coverage drifts over long periods of time, from an almost clear
// sky to somewhat cloudy, instead of staying constant. Three slow sine waves with unrelated periods
// (about 4 min, 15 min and 90 min of play time) never repeat in an obvious way.
// ---------------------------------------------------------------------
float rtv_cloud_weather(float offset)
{
    float t = frameTimeCounter + offset;
    float w = 0.50 * sin(t * 0.0261 + 1.3) + 0.32 * sin(t * 0.0069 + 4.1) + 0.18 * sin(t * 0.00117 + 2.2);
    return clamp(w * 1.25, -1.0, 1.0);   // -1 = almost clear, +1 = most cloudy
}

// current cumulus coverage after the weather was applied (set once per pixel)
float rtv_cov_now = CLOUD_COVERAGE;

// wp: world position, h01: 0 at the cloud base, 1 at the top
float rtv_cloud_density(vec3 wp, float h01, bool detail)
{
    float storm = rtv_storm_factor();
    float wind_offset = frameTimeCounter * 3.0 * CLOUD_SPEED + rtv_cloud_storm_offset();
    vec3 q = wp + vec3(1.0, 0.0, 0.35) * wind_offset;

    // Broad domain warp breaks up the repeated noise pattern and gives cloud banks
    // natural, wind-sheared contours instead of rounded low-poly blobs.
    float broad_warp = rtv_cloud_vnoise(q * 0.0018 + vec3(2.7, 0.0, 8.1)) - 0.5;
    q += vec3(broad_warp * 82.0, 0.0, broad_warp * 54.0);

    // Large scale: the weather front and the main cloud masses.
    vec3 qb = q * vec3(0.0011, 0.0, 0.0011) + vec3(0.0, 0.37, 0.0);
    float base = (0.50 * rtv_cloud_vnoise(qb) + 0.25 * rtv_cloud_vnoise(qb * 2.03 + 7.1) + 0.125 * rtv_cloud_vnoise(qb * 4.1 + 3.3)) / 0.875;

    // Medium scale: billows and wind-formed lobes.
    vec3 qs = q * vec3(0.0060, 0.0085, 0.0060);
    float bil = (0.48 * rtv_cloud_vnoise(qs) + 0.30 * rtv_cloud_vnoise(qs * 2.07 + 1.9) + 0.22 * rtv_cloud_vnoise(qs * 4.3 + 5.2)) / 0.875;

    // Smaller cauliflower structures add real cloud-body variation without polygon edges.
    vec3 qc = q * vec3(0.0150, 0.0190, 0.0150) + vec3(3.1, 0.0, 8.4);
    float cau = 0.60 * rtv_cloud_vnoise(qc) + 0.40 * rtv_cloud_vnoise(qc * 2.1 + 5.0);

    // flat bottom, but the TOP height follows the large-scale noise: big masses grow into towers, thin ones stay low.
    // (a constant profile gave every cloud the same flat-topped pancake shape)
    float top = mix(0.30, 1.0, smoothstep(0.30, 0.85, base));
    float prof = smoothstep(0.0, 0.08, h01) * (1.0 - smoothstep(top * 0.35, top, h01));

    float shape = base * 0.50 + bil * 0.38 + cau * 0.12;
    float thr = 0.98 - rtv_cov_now * (0.52 + 0.06 * storm);
    float d = shape * 0.85 + 0.30 * prof - thr;
    // A slightly firmer density transition keeps cloud edges defined, while the
    // multi-frequency erosion below prevents a soft, uniformly rounded look.
    d = clamp(d / (0.085 / CLOUD_SHARPNESS), 0.0, 1.0);
    d = d * d * (3.0 - 2.0 * d);

    // Multi-frequency edge erosion: tiny wisps and scalloped edges are only evaluated
    // for the visible ray samples, not the cheaper self-shadow samples.
    if (detail && d > 0.0)
    {
        float det0 = rtv_cloud_vnoise(q * 0.034 + 3.7);
        float det1 = rtv_cloud_vnoise(q * 0.073 + 11.0);
        float det2 = rtv_cloud_vnoise(q * 0.145 + 23.4);
        float erosion = det0 * 0.52 + det1 * 0.31 + det2 * 0.17;
        float edge_weight = 1.0 - smoothstep(0.48, 0.96, d);
        d = clamp(d - (1.0 - d) * (0.20 + 0.14 * CLOUD_SHARPNESS + 0.24 * storm) * erosion * edge_weight, 0.0, 1.0);
        d *= mix(1.0, smoothstep(0.08, 0.34, erosion), 0.14 * edge_weight);
    }
    return d * sqrt(prof) * CLOUD_DENSITY * mix(1.0, 1.22, storm);
}

float rtv_cloud_hg(float c, float g)
{
    return (1.0 - g * g) / pow(1.0 + g * g - 2.0 * g * c, 1.5);
}

vec4 rtv_cumulus_clouds(in vec3 dir, in vec3 sun_dir, in float jitter)
{
    vec3 cam = cameraPosition;
    float base_y = float(CLOUD_HEIGHT);
    float top_y = base_y + float(CLOUD_THICKNESS);

    if (abs(dir.y) < 1e-4) return vec4(0.0, 0.0, 0.0, 1.0);

    float t0 = (base_y - cam.y) / dir.y;
    float t1 = (top_y - cam.y) / dir.y;
    float tmin = max(min(t0, t1), 0.0);
    float tmax = max(t0, t1);
    // no hard distance cut: the clouds now reach the horizon
    if (tmax <= 0.0 || tmin > 60000.0) return vec4(0.0, 0.0, 0.0, 1.0);
    tmax = min(tmax, tmin + 6000.0);

    // Steps are packed close to the camera and spread out far away (a uniform step over a 6000 block grazing ray was ~190 blocks long,
    // which smeared the near clouds into a flat, blurry sheet).
    float span = tmax - tmin;
    float inv_n = 1.0 / float(CLOUD_STEPS_USED);

    float cos_sun = dot(dir, sun_dir);
    float phase = clamp((rtv_cloud_hg(cos_sun, 0.6) * 0.7 + rtv_cloud_hg(cos_sun, -0.25) * 0.3) * 0.45, 0.0, 4.0);

    // tint of the sky light that fills the clouds from above
    vec3 sky_tint = skyColor * (0.95 / max(max(skyColor.r, skyColor.g), max(skyColor.b, 0.01)));
    vec3 ambient_tint = mix(vec3(0.62, 0.74, 0.95), sky_tint, 0.5);
    float storm = rtv_storm_factor();
    // Storm cloud undersides become cool grey; sunlight remains visible on the upper edges.
    ambient_tint = mix(ambient_tint, vec3(0.40, 0.45, 0.54), storm * 0.72);
    vec3 sun_tint = vec3(1.0, 0.97, 0.90);

    float sun_up = smoothstep(-0.03, 0.12, sun_dir.y);

    float trans = 1.0;
    vec3 acc = vec3(0.0);

    for (int s = 0; s < CLOUD_STEPS_USED; s++)
    {
        float su = (float(s) + jitter) * inv_n;
        float t = tmin + span * pow(su, 1.45);
        float dt = span * 1.45 * pow(max(su, 0.04), 0.45) * inv_n;
        vec3 wp = cam + dir * t;
        float h01 = clamp((wp.y - base_y) / (top_y - base_y), 0.0, 1.0);
        float den = rtv_cloud_density(wp, h01, t < 3500.0);   // far away: skip the fine detail (it would only alias)
        if (den > 0.003)
        {
            // how much cloud is between this point and the sun
            float od = 0.0;
            float l = 10.0;
            for (int k = 0; k < CLOUD_LIGHT_STEPS; k++)
            {
                vec3 lp = wp + sun_dir * l;
                float lh = clamp((lp.y - base_y) / (top_y - base_y), 0.0, 1.0);
                od += rtv_cloud_density(lp, lh, false) * l * 0.5;
                l *= 2.0;
            }
            // Beer-Lambert + a weak multiple-scattering term: deep cloud interiors get dark and grey, lit edges stay bright
            float t_sun = max(exp(-od * 0.075 * CLOUD_SHADING), 0.22 * exp(-od * 0.014));
            float powder = 1.0 - exp(-den * 21.0);

            // powder effect kept weak: thin sunlit edges stay bright (silver lining) instead of going grey
            vec3 sun_light = sun_tint * (t_sun * (0.72 + 0.28 * powder)) * phase * 2.1 * sun_up;
            sun_light *= mix(1.0, 0.66, storm);
            vec3 amb_light = ambient_tint * (0.24 + 0.76 * pow(h01, 0.8)) * 0.80;   // darker, bluish-grey undersides, bright tops

            vec3 col = sun_light * rtv_sunlight_factor() * rtv_sun_color() + amb_light * rtv_sky_illumination_factor();

            float a = 1.0 - exp(-den * dt * 0.48);
            acc += trans * a * col;
            trans *= 1.0 - a;
            if (trans < 0.02) break;
        }
    }

    // fade into the haze toward the horizon and with distance
    // (much gentler than before so the clouds stay visible all the way to the horizon)
    float fade = exp(-tmin * 0.000032) * smoothstep(0.0, 0.012, abs(dir.y));
    trans = 1.0 - (1.0 - trans) * fade;
    acc *= fade;

    return vec4(acc * CLOUD_BRIGHTNESS, trans);
}

// ---------------------------------------------------------------------
// Cirrus: thin, high, wispy streaks on a single plane far above the cumulus layer.
// Coverage follows its own slow weather cycle, and the layer reaches the horizon.
// ---------------------------------------------------------------------
#if CIRRUS_CLOUDS == 1
vec4 rtv_cirrus_clouds(in vec3 dir, in vec3 sun_dir, in float jitter)
{
    float cirrus_y = float(CLOUD_HEIGHT) + 1800.0;
    if (dir.y < 0.0015 || cameraPosition.y > cirrus_y) return vec4(0.0, 0.0, 0.0, 1.0);

    float t = (cirrus_y - cameraPosition.y) / dir.y;
    vec2 xz = (cameraPosition + dir * t).xz;

    float drift = frameTimeCounter * CLOUD_SPEED * 6.0 + rtv_cloud_storm_offset() * 2.0;
    vec2 p = xz + vec2(1.0, 0.45) * drift;

    // streaks: stretch the noise along one direction and bend it with a lower frequency warp
    float warp = rtv_cloud_vnoise(vec3(p * 0.00035, 3.7));
    vec2 q = vec2(p.x * 0.00028 + warp * 0.9, p.y * 0.0017);
    float streak = 0.55 * rtv_cloud_vnoise(vec3(q, 1.3)) + 0.30 * rtv_cloud_vnoise(vec3(q * 2.1 + 4.0, 2.9)) + 0.15 * rtv_cloud_vnoise(vec3(q * 4.3 + 9.0, 5.1));

    // where the cirrus lives: patches that appear and vanish with their own, different weather cycle
    float patch_n = 0.65 * rtv_cloud_vnoise(vec3(p * 0.00018, 8.2)) + 0.35 * rtv_cloud_vnoise(vec3(p * 0.00046, 2.4));
    float cov_natural = clamp(0.42 + 0.30 * rtv_cloud_weather(1700.0) * CLOUD_COVERAGE_VARIATION, 0.05, 0.85);
    float cov = mix(cov_natural, max(cov_natural, 0.92), rtv_storm_factor());
    float thr = 0.78 - cov * 0.42;
    float d = smoothstep(thr, thr + 0.28, patch_n * 0.65 + streak * 0.55);
    d *= smoothstep(0.30, 0.62, streak);          // thin streaky structure inside the patches
    d *= CIRRUS_AMOUNT;

    // haze with distance, but only mild: it still shows up at the horizon
    float dist = t;
    float fade = exp(-dist * 0.000012) * smoothstep(0.0, 0.015, dir.y);
    float alpha = clamp(d * 0.55 * fade, 0.0, 0.8);
    if (alpha < 0.002) return vec4(0.0, 0.0, 0.0, 1.0);

    float cos_sun = dot(dir, sun_dir);
    float phase = 0.35 + clamp(rtv_cloud_hg(cos_sun, 0.7) * 0.18, 0.0, 1.6);
    float sun_up = smoothstep(-0.03, 0.12, sun_dir.y);

    vec3 sky_tint = skyColor * (0.95 / max(max(skyColor.r, skyColor.g), max(skyColor.b, 0.01)));
    vec3 ambient_tint = mix(vec3(0.62, 0.74, 0.95), sky_tint, 0.5);
    float storm = rtv_storm_factor();
    ambient_tint = mix(ambient_tint, vec3(0.42, 0.47, 0.56), storm * 0.70);
    vec3 sun_tint = vec3(1.0, 0.97, 0.90);

    vec3 col = sun_tint * phase * 1.6 * sun_up * rtv_sunlight_factor() * rtv_sun_color() * mix(1.0, 0.68, storm)
             + ambient_tint * 0.85 * rtv_sky_illumination_factor();

    return vec4(col * alpha * CLOUD_BRIGHTNESS, 1.0 - alpha);
}
#endif


// ---------------------------------------------------------------------
// Altocumulus: a middle layer of soft rolls / puffs between the cumulus and the cirrus.
// Single plane, cheap: it gets self-shadowing from one offset sample toward the sun and turns orange at sunset.
// ---------------------------------------------------------------------
#if CLOUD_LAYERS == 1
float rtv_alto_density(vec2 p)
{
    float warp = rtv_cloud_vnoise(vec3(p * 0.00045, 11.0));
    vec2 q = p * 0.0011 + vec2(warp * 0.8, warp * 0.5);
    // elongated puffs: stretch along x a little
    float n = 0.50 * rtv_cloud_vnoise(vec3(q.x * 0.8, q.y * 1.3, 4.1)) + 0.30 * rtv_cloud_vnoise(vec3(q * 2.3 + 6.0, 7.7)) + 0.20 * rtv_cloud_vnoise(vec3(q * 5.1 + 2.0, 1.9));
    float cov_natural = clamp(0.38 + 0.32 * rtv_cloud_weather(900.0) * CLOUD_COVERAGE_VARIATION, 0.05, 0.85);
    float cov = mix(cov_natural, max(cov_natural, 0.90), rtv_storm_factor());
    float thr = 0.74 - cov * 0.38;
    return smoothstep(thr, thr + 0.16, n);
}

vec4 rtv_alto_clouds(in vec3 dir, in vec3 sun_dir, in float jitter)
{
    float alto_y = float(CLOUD_HEIGHT) + 650.0;
    if (dir.y < 0.0015 || cameraPosition.y > alto_y) return vec4(0.0, 0.0, 0.0, 1.0);

    float t = (alto_y - cameraPosition.y) / dir.y;
    vec2 alto_drift = vec2(0.8, 0.35) * (frameTimeCounter * CLOUD_SPEED * 4.0 + rtv_cloud_storm_offset());
    vec2 p = (cameraPosition + dir * t).xz + alto_drift;

    float d = rtv_alto_density(p);
    float fade = exp(-t * 0.000010) * smoothstep(0.0, 0.015, dir.y);
    float alpha = clamp(d * 0.80 * fade, 0.0, 0.92);
    if (alpha < 0.002) return vec4(0.0, 0.0, 0.0, 1.0);

    // thickness toward the sun decides how dark the cloud is
    vec2 sun_step = normalize(sun_dir.xz + vec2(1e-4)) * 220.0;
    float d_sun = rtv_alto_density(p + sun_step);
    float shade = clamp(1.0 - 0.55 * max(d_sun - d * 0.5, 0.0), 0.35, 1.0);

    float cos_sun = dot(dir, sun_dir);
    float phase = 0.55 + clamp(rtv_cloud_hg(cos_sun, 0.6) * 0.16, 0.0, 1.4);
    float sun_up = smoothstep(-0.03, 0.12, sun_dir.y);
    // Keep the v0.7 restrained sunlight palette. Time-of-day warmth comes from rtv_sun_color(),
    // rather than a second hard-coded orange filter on the whole cloud layer.
    vec3 sun_tint = vec3(1.0, 0.97, 0.90);

    vec3 sky_tint = skyColor * (0.95 / max(max(skyColor.r, skyColor.g), max(skyColor.b, 0.01)));
    vec3 ambient_tint = mix(vec3(0.62, 0.74, 0.95), sky_tint, 0.5);
    float storm = rtv_storm_factor();
    ambient_tint = mix(ambient_tint, vec3(0.40, 0.46, 0.55), storm * 0.70);
    vec3 col = sun_tint * phase * 1.5 * shade * sun_up * rtv_sunlight_factor() * rtv_sun_color() * mix(1.0, 0.68, storm)
             + ambient_tint * 0.80 * (0.6 + 0.4 * shade) * rtv_sky_illumination_factor();
    return vec4(col * alpha * CLOUD_BRIGHTNESS, 1.0 - alpha);
}
#endif

vec4 rtv_volumetric_clouds(in vec3 dir, in vec3 sun_dir, in float jitter)
{
    // weather: coverage slowly moves between almost clear (w = -1) and CLOUD_COVERAGE = "somewhat cloudy" (w = +1)
    float w = rtv_cloud_weather(0.0);
    float v = clamp(CLOUD_COVERAGE_VARIATION, 0.0, 1.0);
    float natural_coverage = CLOUD_COVERAGE * mix(1.0, 0.5 + 0.5 * w, v)
        * (1.0 + 0.25 * max(CLOUD_COVERAGE_VARIATION - 1.0, 0.0));
    // Iris wetness rises as rain/storm starts. The smooth blend gathers a dense
    // cloud deck across the sky rather than popping in as a separate layer.
    rtv_cov_now = clamp(mix(natural_coverage, max(natural_coverage, 0.97), rtv_storm_factor()), 0.0, 1.0);

    vec4 res = rtv_cumulus_clouds(dir, sun_dir, jitter);
    // higher layers sit behind the lower ones: alto first, cirrus last
    #if CLOUD_LAYERS == 1
        vec4 alto = rtv_alto_clouds(dir, sun_dir, jitter);
        res = vec4(res.rgb + res.a * alto.rgb, res.a * alto.a);
    #endif
    #if CIRRUS_CLOUDS == 1
        vec4 cir = rtv_cirrus_clouds(dir, sun_dir, jitter);
        res = vec4(res.rgb + res.a * cir.rgb, res.a * cir.a);
    #endif
    return res;
}

#endif
