#version 430 compatibility

#include "/stuff/settings.glsl"

uniform float viewHeight;
uniform float viewWidth;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform vec3 sunPosition;

in vec4 starData; //rgb = star color, a = flag for whether or not this pixel is a star.

#if PROCEDURAL_SKY == 1
	#include "/stuff/procedural_sky.glsl"
#endif

float fogify(float x, float w) {
	return w / (x * x + w);
}

vec3 calcSkyColor(vec3 pos) {
	float upDot = dot(pos, gbufferModelView[1].xyz); //not much, what's up with you?
	return mix(skyColor, fogColor, fogify(max(upDot, 0.0), 0.25));
}

vec3 screenToView(vec3 screenPos) {
	vec4 ndcPos = vec4(screenPos, 1.0) * 2.0 - 1.0;
	vec4 tmp = gbufferProjectionInverse * ndcPos;
	return tmp.xyz / tmp.w;
}

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 color;

void main() {
	#if PROCEDURAL_SKY == 1 && !defined(DIM_END) && !defined(DIM_NETHER)
		float night = 1.0 - smoothstep(-0.05, 0.15, rtv_day_cycle());
		if (starData.a > 0.5) {
			// the sky is scaled down a lot at night, so the stars get a matching boost to stay visible
			color = vec4(starData.rgb * (1.0 + 14.0 * night), 1.0);
		} else {
			vec3 view_dir = normalize(screenToView(vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), 1.0)));
			vec3 world_dir = normalize(mat3(gbufferModelViewInverse) * view_dir);
			vec3 sun_dir = normalize(mat3(gbufferModelViewInverse) * normalize(sunPosition));
			vec3 procedural_sky = rtv_procedural_sky(world_dir, sun_dir);
			// v0.7 used Minecraft's time/biome-aware skyColor and fogColor. Keep that native
			// warm/cold response as the dominant colour reference, while retaining v0.8's sky shape.
			float upDot = dot(view_dir, gbufferModelView[1].xyz);
			vec3 v07_environment_sky = mix(skyColor, fogColor, fogify(max(upDot, 0.0), 0.25));
			vec3 sky = mix(procedural_sky, v07_environment_sky, clamp(SKY_TEMPERATURE_MATCH, 0.0, 1.0));
			color = vec4(sky, 1.0);
		}
	#else
		if (starData.a > 0.5) {
			color = vec4(starData.rgb, 1.0);
		} else {
			vec3 pos = screenToView(vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), 1.0));
			color = vec4(calcSkyColor(normalize(pos)), 1.0);
		}
	#endif
}
