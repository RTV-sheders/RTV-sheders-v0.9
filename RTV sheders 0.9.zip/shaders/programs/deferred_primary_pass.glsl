// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2026 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

// Purpose:
	// Main Defered Pass: 
		// Primary Lighting & Stuff
		// Debug View of voxelized data
		// Composite the defered stuff on top of the Sky and clouds in colortex 0

// Our Settings
	#include "/stuff/settings.glsl"

// Data from Minecraft / Iris
    uniform vec3 skyColor;
	uniform vec3 cameraPosition;
	uniform vec3 previousCameraPosition;
	#ifndef RTV_FRAMETIME_DECLARED
		uniform float frameTimeCounter;
		#define RTV_FRAMETIME_DECLARED 1
	#endif
	uniform vec3 shadowLightPosition;
	uniform int frameCounter;
	uniform float viewWidth;
	uniform float viewHeight;
	uniform bool hideGUI;
	uniform ivec2 eyeBrightnessSmooth;


	//space transforms
		//are moved into "/stuff/space_transforms.glsl"

// Samplers / Textures / Images
	
	//depth
	uniform sampler2D  depthtex0;
	
	//working scene image
    uniform sampler2D colortex0; // scene image
	
	//defered data
    uniform sampler2D colortex1; // albedo
    uniform sampler2D colortex2; // specular tex 
    uniform sampler2D colortex3; // normals tex (in world space) 
    uniform sampler2D colortex4; // defered_data_1_tex; // vec4(lmcoord,ao,height_map);
	uniform sampler2D colortex5; // vec4 normals_face_world, float material_mask_id
	#if TEMPORAL_ACCUMULATION > 0
		//	uniform sampler2D colortex6; // vec4 hdr_color_and_depth_non_clearing - format: RGBA16F
	// - moved into the reprojection file
	#endif

	//the 3d texture we are writing voxel data to
	layout (r32ui) uniform uimage3D cimage1;
	//our 3d image with voxel data as an interpolated sampler
	uniform usampler3D cSampler1;

// Data from Vertex Shader
    in vec2 texcoord;
	
// Global variables
	vec3 Sun_or_moon_dir_world;
	vec3 Dither_offset;

// Outputs
	#if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0
	//we are going to only write to an RT lighting buffer, as you cannot write to multiple sizes at once
	//we will defer applying the RT lighting to the screen
	
		/* RENDERTARGETS:6,8 */
		layout(location = 0) out vec4 hdr_color_and_depth_non_clearing;
		// how many frames of lighting are accumulated in each pixel, for fast convergence on new pixels and long accumulation on stable ones
		layout(location = 1) out vec4 ta_history_length;
		#define TA_HISTORY_LENGTH 1

		const bool colortex6Clear = false;
		const bool colortex8Clear = false;
		/*
		const int colortex6Format = RGBA16F;
		const int colortex8Format = R16F;
		*/
		
	#else
		#if TEMPORAL_ACCUMULATION > 0 || RT_DENOISING > 0
			/* RENDERTARGETS:0,6 */
			layout(location = 0) out vec4 color;
			layout(location = 1) out vec4 hdr_color_and_depth_non_clearing;

			const bool colortex6Clear = false;
				/*
				const int colortex6Format = RGBA16F;
				*/
		#else
			/* RENDERTARGETS:0 */
			layout(location = 0) out vec4 color;
		#endif
	#endif
	
// Included files 
	#include "/stuff/color/srgb_conversion.glsl"
	#include "/stuff/space_transforms.glsl"
	#include "/stuff/shadowmap_sampling.glsl"
	#define UNPACKING_VOXEL_UVS_HERE 1
	#include "/stuff/uv_packing.glsl"
	#include "/stuff/voxelizing/voxel_packing.glsl"
    #include "/stuff/rt/rt.glsl"
    #include "/stuff/rt/block_light_nee.glsl"
    #include "/stuff/noise/noise_texture.glsl"
	#include "/stuff/noise/noise_functions.glsl"
	#include "/stuff/reprojection.glsl"




// Functions
	#if VISUALIZED_DATA == 6
	// Rays that start in or pass through water must see what is behind the water (sea floor, shore, sky), not the water blocks themselves.
	// Without this the refracted/reflected ray immediately hits the water voxel under the surface, and the water looks white and opaque.
	Traced_ray trace_ray_through_water(in vec3 origin, in vec3 dir)
	{
		Traced_ray r = trace_ray(origin, dir);
		bool in_water = false;
		for(int i = 0; i < 24; i++)
		{
			if(!r.hit_something) { in_water = false; break; }
			ivec3 hit_voxel = ivec3(r.pos + (vec3(float(VOXEL_AREA/2)) + fract(cameraPosition)));
			in_water = unpack_material_flag_from_voxel(imageLoad(cimage1, hit_voxel).r) == 1u;
			if(!in_water) break;
			r = trace_ray(r.pos + dir * 0.01, dir); //continue through the water
		}
		if(in_water && r.hit_something)
		{
			//very deep water: dark blue instead of a lit water block
			r.albedo.rgb = vec3(0.01, 0.05, 0.09) * SUN_BRIGHTNESS * SKY_BRIGHTNESS_IN_RT * rtv_sky_illumination_factor();
		}
		return r;
	}
	#endif

	// Where a ray starting at hit_pos (traced voxel space) leaves the voxel it just hit.
	vec3 rtv_leave_voxel_origin(in vec3 hit_pos, in vec3 dir)
	{
		vec3 shift = vec3(float(VOXEL_AREA) * 0.5) + fract(cameraPosition);
		vec3 q = hit_pos + shift + dir * 0.01;
		vec3 cell = floor(q);
		vec3 next_edge = cell + step(vec3(0.0), dir);
		vec3 safe_dir = vec3(abs(dir.x) < 1e-5 ? 1e-5 : dir.x, abs(dir.y) < 1e-5 ? 1e-5 : dir.y, abs(dir.z) < 1e-5 ? 1e-5 : dir.z);
		vec3 t = (next_edge - q) / safe_dir;
		float t_exit = min(t.x, min(t.y, t.z));
		return hit_pos + dir * (0.01 + max(t_exit, 0.0) + 0.003);
	}

	void progress_dither()
	{
		#if TEMPORAL_ACCUMULATION > 0
			Dither_offset = fract(Dither_offset + random_from_vec2(gl_FragCoord.xy) );
		#endif
	}
	
	vec3 get_screen_dither()
	{	
		#if DITHER_TYPE == 1 || DITHER_TYPE == 3 
			return blue_noise().xyz;
		#endif
		#if DITHER_TYPE == 2
			return vec3(
				random_from_vec2(gl_FragCoord.xy),
				random_from_vec2(gl_FragCoord.xy*(1.238+texcoord)),
				random_from_vec2(gl_FragCoord.xy*(3.1497+texcoord))
				);
		#endif
	}

#if CLOUD_STYLE == 1
	#include "/stuff/volumetric_clouds.glsl"
#endif

void main()
{
	//Setup
	
	vec3 Debug_value; //so we can debug locally coped stuff at the end of the function
	
	//we are going to declare 'color' here just so we don't have to rewrite a bunch of code
	#if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0
		vec4 color;
	#endif
	//never write undefined data into the history buffers (sky pixels, off-screen)
	#if TEMPORAL_ACCUMULATION > 0 || RT_DENOISING > 0
		hdr_color_and_depth_non_clearing = vec4(0.);
	#endif
	#ifdef TA_HISTORY_LENGTH
		ta_history_length = vec4(0.);
	#endif
	
	
	#if RAYTRACING_VIEW == 1
        //we are ray tracing the right half of the screen, so ignore it here
        if(texcoord.x<=.5)
		{
	#endif
	#if RAYTRACING_VIEW == 2
        //we are ray tracing the entire screen, so ignore it here
        if(false)
		{
	#endif
        
    // Load data and unpack
		float depth_tex_read = texture(depthtex0,texcoord).r;
		bool primary_ray_hit = depth_tex_read<1.;

		if(primary_ray_hit)
		{
			
			vec4 albedo = texture(colortex1, texcoord);
			vec4 specular_tex = texture(colortex2, texcoord);
			vec4 defered_data_1_tex = texture(colortex4, texcoord);
			vec2 lmcoord = defered_data_1_tex.xy;
			vec4 deferred_data2 =  texture(colortex5, texcoord);
			vec3 normals_face_world = deferred_data2.xyz;
			float material_mask_id = deferred_data2.a;
			bool is_first_person_hand = abs(material_mask_id - 101.0) < 0.5;
            bool is_entity_pixel = abs(material_mask_id - 100.0) < 0.5;
			
		
			vec3 normals_texture_world =  texture(colortex3, texcoord).xyz;
			
			//unpack 
			albedo.rgb = srgb_to_linear(albedo.rgb);
			float sss = specular_tex.b < 64.5? specular_tex.b/64. : 0.;
			

			vec3 view_dir_world;
			   { //scoped to remove variables from memory as soon as we don't need them anymore
					vec3 direction_screen = vec3(texcoord, 1.);
					vec3 direction_view = screen_to_view_space(direction_screen);
					view_dir_world = normalize( view_to_foot_direction(direction_view) );
				}

			// fix imposible viewing angles from normal textues that point away from the camera
			if( dot(normals_texture_world,view_dir_world) > 0. )  normals_texture_world = normals_face_world;

			#if USE_TEXTURE_NORMALS == 0
				normals_texture_world = normals_face_world;
			#endif
			
			vec3 foot_pos;
			   { //scoped to remove variables from memory as soon as we don't need them anymore
					vec3 position_screen = vec3(texcoord, depth_tex_read);
					vec3 position_view = screen_to_view_space(position_screen);
					foot_pos = view_to_foot_space(position_view);
				}

		//Load a Dither / Randomness / Offset
			Dither_offset = get_screen_dither();
			//change per frame
			#if TEMPORAL_ACCUMULATION > 0
				#if TEMPORAL_ACCUMULATION == 1
					if(hideGUI) Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
				#else
					Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
				#endif
			#endif
			
		// Apply our lighting
			//get sun diresction in the world
				Sun_or_moon_dir_world = normalize(
						view_to_foot_direction(shadowLightPosition)
						 #if SOFT_RT_SHADOWS == 1 && SHADOWS_USED_ON_SCREEN == 1
							+ SUN_WIDTH * (2.*Dither_offset.xyz-1.)
						#endif
					);
					
			vec3 sky_light = lmcoord.y* (skyColor) * (dot(normals_texture_world,vec3(0.,1.,0.)) *.5 + .5 ) //sky light shading
				;
			vec3 block_light = lmcoord.x*vec3(1.,.9,.5);
			float emmission = specular_tex.a * BLOCK_LIGHT_BRIGHTNESS; //emission
			
			float sun_lighting;
			vec3 sunlight_color_here = vec3(1.);
		
			// Shadows
			#if SHADOWS_USED_ON_SCREEN == 1
			//RT shadows
				 
				//get ray starting position
				vec3 ray_starting_pos = foot_pos;

				//trace ray
				//shadow ray
					sun_lighting = dot(normals_face_world,Sun_or_moon_dir_world);
					if(sun_lighting>0.01)
					{
						sun_lighting = dot(normals_texture_world,Sun_or_moon_dir_world);
						
						#if RT_API >= 6
							#if COLORED_RT_SHADOWS == 1
								#if RT_SHADOW_TEXTURES == 1
									Traced_shadow_ray traced_ray =  trace_shadow_ray_tinted_cutout( ray_starting_pos+Sun_or_moon_dir_world*.001, Sun_or_moon_dir_world);
								#else
									Traced_shadow_ray traced_ray =  trace_shadow_ray_tinted( ray_starting_pos+Sun_or_moon_dir_world*.001, Sun_or_moon_dir_world);
								#endif
								
							  
								sunlight_color_here*= traced_ray.tint;
							#else
								Traced_shadow_ray traced_ray =  trace_shadow_ray( ray_starting_pos+Sun_or_moon_dir_world*.001, Sun_or_moon_dir_world);
							#endif
						#else
							Traced_ray traced_ray = trace_ray( ray_starting_pos+Sun_or_moon_dir_world*.001, Sun_or_moon_dir_world);
						#endif

						sunlight_color_here = (traced_ray.hit_something) ? vec3(0.):sunlight_color_here* max(0.,sun_lighting);
					}else{
						sunlight_color_here=vec3(0.);
					}
			#endif
			//> RT shadows
		
			#if SHADOWS_USED_ON_SCREEN == 2
			//shadowmap
				sun_lighting = dot(normals_face_world,Sun_or_moon_dir_world);
				if(sun_lighting>0.01)
				{
					sun_lighting = dot(normals_texture_world,Sun_or_moon_dir_world);
					if(sun_lighting>0.01)
					{
						sunlight_color_here *= get_shadows_at_foot_pos(foot_pos,normals_face_world, Dither_offset, sss, sun_lighting);
					}
					sunlight_color_here*= max(0.,sun_lighting);
				}else{
					sunlight_color_here=vec3(0.);
				}
			#endif
		
			//no direct sun in caves / covered areas (shadow map can leak there)
			sunlight_color_here *= smoothstep(0.02, 0.25, lmcoord.y);
			//block light (torches, lanterns, lamps) is not added here: it is fully ray traced, see rt_block_light() below

            // Reused diffuse GI ray provides contact visibility for entity ambient fill.
            float entity_ao_visibility = 1.0;
			float held_light_luma = 0.0; //brightness added by the held-item light on this pixel (used to shorten the temporal history)

			vec3 lighting = sunlight_color_here * SUN_BRIGHTNESS * SUN_SURFACE_STRENGTH * rtv_sunlight_factor() * rtv_sun_color()
				#if VANILLA_BLOCK_LIGHT_ON_SCREEN == 1
					 + block_light
				#endif
				#if VANILLA_SKY_LIGHT_ON_SCREEN == 1
					+ sky_light
				#endif
				#if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0
					// Emission is added by the final pass, AFTER denoising (see rt_upscaling_and_denoising_final.glsl).
					// Keeping a value this large (lamps = 72) inside the lighting buffer made the blur spread it into neighbouring pixels as a halo.
					+ vec3(0.0);
				#else
					+ emmission;
				#endif
			
			

            // ---- mapped foliage backlight ----
            // A restrained transmitted-light term for leaf blocks. Only back-facing leaf pixels
            // take one existing shadow-map depth sample; no additional RT rays or render passes.
            if (FOLIAGE_BACKLIGHT_STRENGTH > 0.0)
            {
                float foliage_mask = 1.0 - smoothstep(0.25, 0.75, abs(material_mask_id - 6.0));
                float foliage_back = pow(max(dot(-normals_face_world, Sun_or_moon_dir_world), 0.0), 1.6);
                float foliage_sky_gate = smoothstep(0.025, 0.24, lmcoord.y)
                    * smoothstep(-0.08, 0.14, Sun_or_moon_dir_world.y) * rtv_sunlight_factor();
                if (foliage_mask > 0.5 && foliage_back > 0.025 && foliage_sky_gate > 0.001)
                {
                    vec3 foliage_shadow_ndc = foot_pos_to_shadow_ndc(foot_pos);
                    float foliage_edge = max(abs(foliage_shadow_ndc.x * 2.0 - 1.0), abs(foliage_shadow_ndc.y * 2.0 - 1.0));
                    float foliage_inside = 1.0 - smoothstep(0.90, 1.0, foliage_edge);
                    float foliage_visibility = 1.0;
                    if (foliage_inside > 0.001)
                    {
                        float foliage_texel_world = rtv_shadow_texel_world(foliage_shadow_ndc.xy);
                        vec3 foliage_shadow_pos = foot_pos_to_shadowmap_texcoord(foot_pos + normals_face_world * (foliage_texel_world * 1.25 * SHADOW_BIAS));
                        float foliage_bias = (0.02 + foliage_texel_world * 0.35) * SHADOW_BIAS + 0.10;
                        foliage_shadow_pos.z -= foliage_bias * 0.5 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]);
                        float foliage_depth = texture(shadowtex1, clamp(foliage_shadow_pos.xy, vec2(0.001), vec2(0.999))).r;
                        foliage_visibility = mix(1.0, step(foliage_shadow_pos.z, foliage_depth), foliage_inside);
                    }
                    vec3 foliage_tint = mix(vec3(0.68, 0.86, 0.48), max(albedo.rgb, vec3(0.0)), 0.38);
                    float foliage_energy = foliage_back * foliage_visibility * foliage_sky_gate * FOLIAGE_BACKLIGHT_STRENGTH * 0.040;
                    lighting += foliage_tint * rtv_sun_color() * (SUN_BRIGHTNESS * SUN_SURFACE_STRENGTH) * foliage_energy;
                }
            }

            // Very restrained room fill. Fully enclosed spaces receive only a tiny floor;
            // openings and skylights receive progressively more sky ambient, preserving contrast in caves.
            float room_sky_access = mix(0.015, 1.0, smoothstep(0.02, 0.48, lmcoord.y));
            // The material AO channel is available even when GI / RT is disabled. Apply it to
            // the ambient component only, never to direct sunlight, so texture creases gain depth
            // without making sunlit surfaces artificially dirty.
            float material_ao = clamp(defered_data_1_tex.z, 0.0, 1.0);
            float visual_ao = mix(1.0, material_ao, MATERIAL_AO_STRENGTH);
            // Stronger hemisphere orientation gives top faces more sky and side / underside faces
            // less, preventing large terrain surfaces from reading as one flat, equally-lit plane.
            float room_hemisphere = 0.42 + 0.58 * max(normals_texture_world.y, 0.0);
            vec3 room_ambient_fill = max(skyColor, vec3(0.012, 0.016, 0.024))
                * (SUN_BRIGHTNESS * SKY_BRIGHTNESS_IN_RT * rtv_sky_illumination_factor())
                * ROOM_AMBIENT_STRENGTH * room_sky_access * room_hemisphere * visual_ao;
            lighting += room_ambient_fill;

			// ---- FAR FIELD: edge-aware shading outside the finite RT voxel cube ----
			// Full-resolution RT remains inside the voxel volume. Near and beyond its edge, add a stable
			// distant-field approximation: hemisphere sky fill, sun/ground bounce and normal-oriented SSAO.
			// Measure against the nearest cube face (Chebyshev distance), so diagonal directions do not
			// switch to the far-field approximation prematurely.
			float rtv_far_ao_mul = 1.0;
			#if FAR_GI == 1
			{
				float rtv_voxel_radius = float(VOXEL_AREA) * 0.5;
				float rtv_voxel_edge = max(abs(foot_pos.x), max(abs(foot_pos.y), abs(foot_pos.z)));
				// Blend the inexpensive far-field shading in before the RT voxel boundary.
				// This keeps hills and terrain from losing contact definition as they leave the 128-block RT volume.
				float far_w = smoothstep(rtv_voxel_radius * 0.64, rtv_voxel_radius * 0.92, rtv_voxel_edge)
					* (abs(material_mask_id - 1.0) > 0.5 && !is_first_person_hand ? 1.0 : 0.0);
				if (far_w > 0.001)
				{
					vec3 far_n = normals_texture_world;
					float far_hemi = 0.5 + 0.5 * far_n.y;
					float far_sky_access = smoothstep(0.05, 0.60, lmcoord.y);
					float far_sky_scale = SUN_BRIGHTNESS * SKY_BRIGHTNESS_IN_RT * rtv_sky_illumination_factor();
					vec3 far_sky_col = max(skyColor, vec3(0.02, 0.03, 0.05));
					// differential hemisphere term (the flat sky colour is already added by the missed GI ray)
					// This is a stable material-lighting fallback, not GI. Keep it active when GI_STRENGTH is 0
                    // so distant terrain still has directional sky shading beyond the voxel volume.
                    vec3 far_hemi_term = far_sky_col * far_sky_scale * (far_hemi - 0.75) * 0.9 * far_sky_access * FAR_FIELD_STRENGTH;

					float far_sun_up = max(Sun_or_moon_dir_world.y, 0.0);
					vec3 far_sun_col = SUN_BRIGHTNESS * SUN_SURFACE_STRENGTH * rtv_sunlight_factor() * rtv_sun_color();
					vec3 far_sun_h = normalize(vec3(Sun_or_moon_dir_world.x, 0.0, Sun_or_moon_dir_world.z) + vec3(1e-4));
					float far_away_from_sun = max(-dot(far_n, far_sun_h), 0.0);
					// light bounced off sunlit ground / neighbouring terrain onto shaded and downward faces
					vec3 far_bounce = far_sun_col * far_sun_up * far_sky_access
                        * (vec3(0.52, 0.46, 0.30) * 0.08 * (1.0 - far_hemi) + vec3(0.95, 0.80, 0.60) * 0.055 * far_away_from_sun)
                        * FAR_FIELD_STRENGTH * visual_ao;
					lighting.rgb += far_w * (far_hemi_term * visual_ao + far_bounce);
					lighting.rgb = max(lighting.rgb, vec3(0.0));

					// normal oriented SSAO, 8 taps
					vec3 far_pc = screen_to_view_space(vec3(texcoord, depth_tex_read));
					vec3 far_nv = normalize(mat3(gbufferModelView) * far_n);
					// Slightly wider screen footprint preserves broad terrain contact at long view distances.
					float far_rad = clamp(2.65 * gbufferProjection[1][1] * 0.5 / max(-far_pc.z, 1.0), 0.0015, 0.06);
					float far_aspect = viewHeight / max(viewWidth, 1.0);
					float far_occ = 0.0;
					for (int fi = 0; fi < 8; fi++)
					{
						float fa = (float(fi) + Dither_offset.x) * 2.399963;
						float fr = far_rad * (0.35 + 0.65 * fract(float(fi) * 0.618034 + Dither_offset.y));
						vec2 fuv = clamp(texcoord + vec2(cos(fa) * far_aspect, sin(fa)) * fr, vec2(0.001), vec2(0.999));
						float fd = texture(depthtex0, fuv).r;
						if (fd < 1.0)
						{
							vec3 fv = screen_to_view_space(vec3(fuv, fd)) - far_pc;
							float fdist = max(length(fv), 0.001);
							far_occ += max(dot(far_nv, fv / fdist) - 0.12, 0.0) * (1.0 - smoothstep(2.0, 6.0, fdist));
						}
					}
					float far_ao = 1.0 - clamp(far_occ * 0.125 * 2.2, 0.0, 1.0) * 0.85 * AO_STRENGTH;
					rtv_far_ao_mul = mix(1.0, far_ao, far_w);
					lighting.rgb *= mix(1.0, far_ao, far_w * 0.7);
				}
			}
			#endif

			#if GLOBAL_ILLUMINATION > 0
				//diffuse - scattered soft light that we solved analytically or with Vanilla lighting
				color.rgb = albedo.rgb * lighting;
					
				//Global Illumination
					// we are going to trace diffuse & specular light
					// one trace will give us both solar gi and block light shadows
			
				//trace bounce light (this verbage might be more intuitive than reflection in the case of diffuse)
				
				//first we calculate fresnel, for the chance of surface reflection vs diffuse scatter
				// Rough surfaces have no fresnel sheen: only smooth ones (water, glass, ice, polished metal) get mirror-like rays.
				// Without this every grazing grass / dirt pixel randomly turned into a noisy mirror ray.
				float fresnel_smoothness = specular_tex.r * specular_tex.r;
				float fresnel = pow( max(0., 1.- abs(dot( view_dir_world, normals_texture_world))) ,6.) * fresnel_smoothness;
				float shininess = specular_tex.g +(1.-specular_tex.g)*fresnel;
				bool reflecting = (Dither_offset.x<shininess);//the probability of a ray reflecting is based on f0 and fresnel
				
				progress_dither();// to ensure randomness of different things that need it aren't synchronized, as that would be broken
				bool refracting = !reflecting && albedo.a<.999;

				//refraction also works from the back side (looking at the surface from underwater / inside glass), with total internal reflection
				vec3 refract_normal = normals_texture_world;
				float refract_eta = abs(material_mask_id - 4.0) < 0.5 ? ICE_REFRACT_INDEX : GLASS_REFRACT_INDEX;
				if(dot(view_dir_world, refract_normal) > 0.) { refract_normal = -refract_normal; refract_eta = 1./refract_eta; }
				vec3 refracted_ray_angle = refract(view_dir_world, refract_normal, refract_eta);
				if(dot(refracted_ray_angle, refracted_ray_angle) < 0.0001) refracted_ray_angle = reflect(view_dir_world, refract_normal);

				vec3 reflected_ray_angle = 
					normalize( 
						(reflecting? 
							reflect(view_dir_world, normals_texture_world ) //specular
							: 
							(
								refracting?	
									refracted_ray_angle //refract
									: normals_texture_world //diffuse
							)
						)
						
						+ (1.-specular_tex.r) * .68 * (2.*Dither_offset.xyz-1.) //scatter via roughness / smoothness
					);
			

                if(!refracting)		
                {
                    if(dot(reflected_ray_angle,normals_face_world)<0.)reflected_ray_angle*=-1; //invert inward rays
				    //recalculate for the actual fresnel of the scattered ray, after accounting for surface smoothness
				    // deterministic (mirror direction, not the random scattered ray) so the tint does not flicker from pixel to pixel
				    fresnel = pow( max(0., dot( view_dir_world, reflect(view_dir_world, normals_texture_world))) ,6.) * fresnel_smoothness;
				    shininess = specular_tex.g +(1.-specular_tex.g)*fresnel;
                }
				
				//we run all rays for GI: no threshholding reflections  - 
				{	
					//trace ray
                    // Geometric-normal bias prevents self-intersection on stairs, slabs and thin faces.
                    float face_side = dot(reflected_ray_angle, normals_face_world) >= 0.0 ? 1.0 : -1.0;
                    vec3 ray_origin = foot_pos + normals_face_world * (0.015 * face_side) + reflected_ray_angle * 0.005;
                    Traced_ray traced_ray;
					#if RT_API == 6
						rtv_hit_ambient_scale = reflecting ? 1.0 : 0.0;
					#endif
					#if VISUALIZED_DATA == 6
						if(abs(material_mask_id-1.) < .5) traced_ray = trace_ray_through_water(ray_origin, reflected_ray_angle);
                    #if RT_API == 6 || RT_API == 7
						else traced_ray = trace_ray(ray_origin, reflected_ray_angle, refracting);
                    #else
                        else traced_ray = trace_ray(ray_origin, reflected_ray_angle);
                    #endif
					#else
						traced_ray = trace_ray(ray_origin, reflected_ray_angle);
					#endif
					// Mobs are not bounce sources: a diffuse ray that ends on a mob continues behind it, so mob colors never bleed onto blocks.
					#if VISUALIZED_DATA == 6
						if (!reflecting && !refracting && traced_ray.hit_something && traced_ray.hit_mob)
						{
							vec3 after_mob_origin = rtv_leave_voxel_origin(traced_ray.pos, reflected_ray_angle);
							#if RT_API == 6 || RT_API == 7
								traced_ray = trace_ray(after_mob_origin, reflected_ray_angle, refracting);
							#else
								traced_ray = trace_ray(after_mob_origin, reflected_ray_angle);
							#endif
						}
					#endif
					vec3 reflection_color = traced_ray.albedo.rgb;
					#if RTV_PHONE == 1
						reflection_color = rtv_safe3(reflection_color, 100000.); //phone: never let NaN / Inf from a ray reach the history
					#endif
                    #if RT_BLOCK_LIGHT_BOUNCE == 1 && RT_BLOCK_LIGHT_NEE == 1 && RT_API >= 6
                    // One short, shadow-tested emitter sample at the GI/reflection hit lets torch/lantern colour
                    // illuminate the surface seen by the ray instead of leaving the reflected room black.
                    if (!refracting && traced_ray.hit_something)
                    {
                        vec3 secondary_block_light = RTV_SAFE_NEE(rt_block_light_bounce(
                            traced_ray.pos, traced_ray.normals_face, traced_ray.normals_face,
                            fract(Dither_offset.zxy + vec3(0.37, 0.61, 0.83))));
                        // a mirror ray sees the torch-lit surface at full brightness; the reduced strength is only for the diffuse GI bounce
                        reflection_color += traced_ray.surface_albedo * secondary_block_light * (reflecting ? 1.0 : RT_BLOCK_LIGHT_BOUNCE_STRENGTH);
                    }
                    #endif
					// Firefly control: clamp rare high-energy one-ray GI hits before accumulation.
					// Normal color bleed remains, while isolated bright/colorful flecks are suppressed.
					// Strengthen and colour-grade ONLY diffuse GI. This is the light-energy
					// transfer from a sunlit / coloured hit surface to the receiving surface;
					// mirror and refraction rays retain their physical radiance unchanged.
					if (!reflecting && !refracting)
					{
						reflection_color *= GI_STRENGTH;
						float bounce_gray = dot(max(reflection_color, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));
						reflection_color = mix(vec3(bounce_gray), reflection_color, GI_BOUNCE_SATURATION);
					}
					vec3 reflection_color_uncapped = reflection_color;
					float bounce_luma = dot(max(reflection_color, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));
					float bounce_luma_cap = SUN_BRIGHTNESS * GI_DIFFUSE_BOUNCE_CAP * GI_STRENGTH;
					// The firefly cap is for noisy DIFFUSE bounce only. Mirror-like rays (metal, ice, glass, water) carry the real radiance of what they see;
					// capping them with the diffuse-only energy limit made every sunlit reflection dull and grey.
					float bounce_luma_cap_used = (reflecting || refracting) ? max(bounce_luma_cap, SUN_BRIGHTNESS * 1.25) : bounce_luma_cap;
					if (bounce_luma > bounce_luma_cap_used)
						reflection_color *= bounce_luma_cap_used / max(bounce_luma, 0.001);
					// Do not use mob bodies as diffuse GI bounce sources; keep block bounce and specular visibility.
					bool bounce_hit_mob = false;
					float bounce_emissive = 0.; //emission of the block the bounce ray hit (torch, lantern, glowstone...)
					#if VISUALIZED_DATA == 6
					if (traced_ray.hit_something)
					{
						ivec3 bounce_voxel_pos = ivec3(traced_ray.pos + vec3(float(VOXEL_AREA) * 0.5) + fract(cameraPosition));
						if (all(greaterThanEqual(bounce_voxel_pos, ivec3(0))) && all(lessThan(bounce_voxel_pos, ivec3(VOXEL_AREA))))
						{
							uint bounce_voxel = imageLoad(cimage1, bounce_voxel_pos).r;
							bounce_hit_mob = unpack_material_flag_from_voxel(bounce_voxel) == 5u;
							bounce_emissive = unpack_pbr_from_voxel(bounce_voxel).a;
						}
					}
					#endif
					// RT block light: a ray that hits a light block keeps (almost) all of its energy. The firefly cap above is meant for
					// stray bright hits, but it also clipped torches to about the brightness of the sky; the shader's own light has to be allowed to be bright.
					if (bounce_emissive > 0.01)
					{
						float emissive_luma_cap = bounce_luma_cap + BLOCK_LIGHT_BRIGHTNESS * RT_BLOCK_LIGHT_BOOST;
						reflection_color = reflection_color_uncapped * min(1.0, emissive_luma_cap / max(bounce_luma, 0.001));
					}
					#if AO_MODE > 0
						// Ray traced ambient occlusion, free: it is read from the diffuse GI ray we already traced. A ray that hits something
						// closer than AO_RADIUS means the spot is tucked into a corner or crevice, so the ambient light there is reduced.
						// Light blocks are not occluders, and temporal accumulation + denoising smooth the one sample per frame.
						float ao_visibility = 1.0;
						if (!reflecting && !refracting && traced_ray.hit_something && bounce_emissive < 0.01 && abs(material_mask_id-1.) > .5)
                        {
                            float ao_distance = length(traced_ray.pos - foot_pos);
                            ao_visibility = mix(1.0, pow(smoothstep(0.0, AO_RADIUS, ao_distance), 1.35), AO_STRENGTH);
							// contact darkening also on the direct light, so creases and block edges stay readable in full sun
							lighting.rgb *= mix(1.0, ao_visibility, AO_SUN_MIX);
                            // Apply entity contact AO to the sky fill as well as the traced diffuse contribution.
                            if (is_entity_pixel)
                                entity_ao_visibility = mix(1.0, smoothstep(0.0, ENTITY_AO_RADIUS, ao_distance), ENTITY_AO_STRENGTH);
                        }
						// AO estimated from the diffuse GI ray is a contact cue, not a visibility test
						// for all incoming radiance. A nearby sunlit floor can be the very surface
						// that should bounce light into this pixel; fully applying ao_visibility here
						// used to erase most of that bounce whenever the ray hit within AO_RADIUS.
						reflection_color *= mix(1.0, ao_visibility, GI_AO_MIX);
					#endif
					#if RT_BLOCK_LIGHT_NEE == 1 && RT_API >= 6
						// Ray traced block light. Light blocks near this pixel are found exactly through the emitter grid, so a bounce ray that
						// happens to hit one close by must not add the same light a second time. Further away (beyond the search radius) the bounce
						// ray's emissive hits are still used, which is what lets far light blocks light up distant surfaces a little.
						if (bounce_emissive > 0.01)
							reflection_color *= smoothstep(float(RT_BLOCK_LIGHT_SEARCH * RTV_EMITTER_CELL) + 1.0, float(RT_BLOCK_LIGHT_SEARCH * RTV_EMITTER_CELL) + 5.0, length(traced_ray.pos - foot_pos));
						// Always search the RT emitter grid.  The vanilla light map is not used
						// even as a culling shortcut, so block light remains fully ray traced.
						if (!reflecting && !refracting)
							lighting.rgb += RTV_SAFE_NEE(rt_block_light(foot_pos, normals_face_world, normals_texture_world, Dither_offset.xyz));
						#if HELD_LIGHT == 1
							// Dynamic light from the item in the player's hand. The hand model itself is not lit by it.
							if (!reflecting && !refracting && !is_first_person_hand && (heldBlockLightValue >= 3 || heldBlockLightValue2 >= 3))
							{
								vec3 held_light = RTV_SAFE_NEE(rtv_held_light(foot_pos, normals_face_world, normals_texture_world, Dither_offset.xyz));
								lighting.rgb += held_light;
								held_light_luma = dot(held_light, vec3(0.2126, 0.7152, 0.0722));
							}
						#endif
					#endif
                    // Entity pixels may receive GI from blocks and terrain. Only suppress diffuse rays
                    // whose traced hit is another mob, so entities cannot light each other unnaturally.
					bool suppress_entity_bounce = bounce_hit_mob && !reflecting && !refracting;
					// A ray miss may see the environment even when the reflecting pixel itself is in shadow.
					// Keep only a small ambient floor indoors instead of multiplying the reflection to absolute black.
					if(!traced_ray.hit_something)
					{
						float environment_visibility = max(smoothstep(0.05, 0.55, lmcoord.y), (reflecting || refracting) ? REFLECTION_ENV_FLOOR : 0.035);
						reflection_color *= environment_visibility;
					}
					//water absorption: clear when shallow, gradually bluer/greener with depth
					if(refracting && abs(material_mask_id-1.) < .5 && traced_ray.hit_something)
						reflection_color *= exp(-vec3(0.12, 0.045, 0.022) * WATER_ABSORPTION * clamp(length(traced_ray.pos - foot_pos), 1.0, 64.)); // clear blue transmission; red is absorbed first without making shallow water opaque
							
					//tinting of bounced light, light is tinted when it diffuses into a surface or bounces off metal 
					vec3 tinting = 
						(specular_tex.g>229.6/255.) ? 
						mix(albedo.rgb, vec3(1.), fresnel) //metals
						:
						mix(albedo.rgb, vec3(1.), shininess); //non-metals
						
					
					// Mob pixels receive environmental GI; diffuse rays hitting another mob remain suppressed.
					if (!suppress_entity_bounce)
					{
						#if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0
							//do not apply tint now, just pure lighting itself, so that we can later share lighting between pixels
							// WATER FIX: air itu transparan, sinar matahari tidak boleh dihitung sebagai cahaya diffuse di permukaannya
							// (itu yang bikin air putih saat kena matahari, tapi normal di bayangan). Air hanya menampilkan hasil trace (tembus/pantul).
							if(abs(material_mask_id-1.) < .5) lighting.rgb = reflection_color;
							else lighting.rgb  = lighting.rgb *(1.-shininess) + reflection_color * rtv_far_ao_mul;
							// no longer add emission here, since it depends on color
							//+ emmission * albedo.rgb; //shiny things are still allowed to glow
						#else
							if(abs(material_mask_id-1.) < .5) color.rgb = vec3(0.); //water fix: tanpa diffuse matahari
							color.rgb  = color.rgb*(1.-shininess) + reflection_color * rtv_far_ao_mul * tinting
								+ emmission * albedo.rgb; //shiny things are still allowed to glow
						#endif
					}
					
				}
			#else
				//Our non-GI code for reflections only
				
				//diffuse - scattered soft light
				color.rgb = albedo.rgb * lighting;
					
				//specular - shiny things and reflections
			
				//trace reflection	
				vec3 reflected_ray_angle = normalize( reflect(view_dir_world, normals_texture_world ) + (1.-specular_tex.r) * .9 * (2.*Dither_offset.xyz-1.));
				//if(dot(reflected_ray_angle,normals_face_world)<0.)reflected_ray_angle*=-1; //invert inward rays
				float fresnel = pow( max(0., dot( view_dir_world, reflected_ray_angle)) ,6.);
				float shininess = specular_tex.g +(1.-specular_tex.g)*fresnel;
				if(shininess > 0.001)
				{	
					//reflected_ray_angle = vec3(1.,0.,0.);//Debug
					
					Traced_ray traced_ray = trace_ray(foot_pos+reflected_ray_angle*.001, reflected_ray_angle);
					vec3 reflection_color =	traced_ray.albedo.rgb ;
							
					//metals
					if(specular_tex.g>229.6/255.) reflection_color*=albedo.rgb;
					//add in to scene
					color.rgb  = color.rgb * (1.- shininess) + shininess * reflection_color;
				}
			#endif
			
            // Lift mob pixels in sun shadows with a soft sky-derived fill. The lightmap sky
            // channel prevents this from flattening enclosed caves; the day/night factor keeps nights dark.
            if (is_entity_pixel)
            {
                float entity_sky_access = smoothstep(0.015, 0.42, lmcoord.y);
                float entity_direct_level = clamp(dot(max(sunlight_color_here, vec3(0.0)), vec3(0.3333333)), 0.0, 1.0);
                float entity_shadow_amount = 1.0 - smoothstep(0.04, 0.32, entity_direct_level);
                float entity_hemisphere = 0.72 + 0.28 * max(normals_texture_world.y, 0.0);
                vec3 entity_sky_tint = max(skyColor, vec3(0.035, 0.050, 0.075));
                vec3 entity_ambient_fill = entity_sky_tint
                    * (SUN_BRIGHTNESS * SKY_BRIGHTNESS_IN_RT)
                    * ENTITY_SHADOW_FILL
                    * rtv_sky_illumination_factor()
                    * entity_sky_access
                    * entity_shadow_amount
                    * entity_hemisphere
                    * entity_ao_visibility;
                #if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0
                    lighting.rgb += entity_ambient_fill;
                #else
                    color.rgb += albedo.rgb * entity_ambient_fill;
                #endif
            }

			#include "/stuff/voxelizing/debug_voxelized_data.glsl"




		// Temporal Accumulation
			#if TEMPORAL_ACCUMULATION > 0
			
				//TA amount to use
				#if TEMPORAL_ACCUMULATION == 1
					float ta_here = primary_ray_hit && hideGUI && frameCounter > 20 ? clamp( 1.- distance(cameraPosition,previousCameraPosition) * 1000., 0.,1.) : 0.;
				#endif
				#if TEMPORAL_ACCUMULATION == 2
					float ta_here = primary_ray_hit && frameCounter > TA_BOOTUP_DELAY ? 1. : 0.;	
				#endif
					
				float distance_from_camera = length(foot_pos);
				
				//get last frame's color
				vec2 reprojected_uv_here;
				float reprojected_count_here;
				vec4 last_frame_hdr_color_and_TA;
				#if TA_HAND == 1
					if (is_first_person_hand)
						last_frame_hdr_color_and_TA = reproject_hand_light(texcoord, distance_from_camera, reprojected_uv_here, reprojected_count_here);
					else
				#endif
						last_frame_hdr_color_and_TA = reproject_bounce_light(foot_pos,distance_from_camera,reprojected_uv_here,reprojected_count_here);
							
				// apply Calculated reprojection value
				ta_here*= last_frame_hdr_color_and_TA.a; 
				
				//fix mirrors
				#if TA_IS_PBR_AWARE == 1
					ta_here*= 1.-pow(specular_tex.g*specular_tex.r,TA_PBR_REJECTION_EXPONENT);
				#endif
				
				// First-person hand (mask 101) has its own screen-space history path.
				#if TA_HAND == 0
					ta_here *= is_first_person_hand ? 0.0 : 1.0;
				#endif
				// Mob/entity pixels use world reprojection and can be toggled independently.
				#if TA_MOBS == 0
					ta_here *= abs(material_mask_id - 100.0) < 0.5 ? 0.0 : 1.0;
				#endif
				
				#if DEBUG_TA == 1
					Debug_value.x = ta_here; // Debug view for TA
				#endif

                //fix refractions
                #if TA_REFRACTIONS == 0
                    if(refracting) ta_here = 0.;
				#endif
				// Anti-ghosting: lower the history weight where the history no longer matches
					// slight reduction while moving fast (strong reduction makes the noise stick to the screen)
					float motion_px = length((reprojected_uv_here - texcoord) * vec2(viewWidth, viewHeight));
					float ta_final = ta_here * TEMPORAL_ACCUMULATION_MAX * mix(1.0, 0.85, smoothstep(2.0, 40.0, motion_px));
					if(is_first_person_hand) ta_final *= 0.55; // softer history for hand/item animation
					#if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0
						vec3 ta_current_rgb = lighting.rgb;
					#else
						vec3 ta_current_rgb = color.rgb;
					#endif
					#if RTV_PHONE == 1
						ta_current_rgb = rtv_safe3(ta_current_rgb, 100000.);
					#endif
					float ta_lum_now = dot(ta_current_rgb, vec3(0.2126,0.7152,0.0722));
					float ta_lum_last = dot(last_frame_hdr_color_and_TA.rgb, vec3(0.2126,0.7152,0.0722));
					// history much brighter than now = old light that is gone (trail). Only big differences count, because single ray samples are naturally noisy.
					ta_final *= 1.0 - smoothstep(4.0, 7.0, log2((ta_lum_last+1.0)/(ta_lum_now+1.0)));
					// firefly limit: a lone very bright ray sample may not blow up the history (this is the noise in dark rooms)
					vec3 ta_limited_rgb = min(ta_current_rgb, last_frame_hdr_color_and_TA.rgb * 12. + 8.);
					ta_current_rgb = mix(ta_current_rgb, ta_limited_rgb, clamp(ta_final * 2., 0., 1.));
					#if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0
						lighting.rgb = ta_current_rgb;
					#else
						color.rgb = ta_current_rgb;
					#endif
				// water surface reflects a changing view, mobs move on their own
					if(abs(material_mask_id-1.) < .5) ta_final *= 0.6;
					if(abs(material_mask_id-100.) < .5) ta_final *= 0.7;

				//accumulate color data over frames by using a fading history
				#if RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0
					// just the lighting is saved now, not the total scene
					// history length based accumulation: a new or invalidated pixel takes the current ray fully (no smeared start),
					// a stable pixel keeps adding frames up to the History Weight limit, which averages out far more noise
					float ta_validity = clamp(ta_final / max(TEMPORAL_ACCUMULATION_MAX, 0.001), 0., 1.);
					float history_n = min(reprojected_count_here, 255.) * ta_validity;
					// water: the surface and the refracted view behind it move with the waves, so a long history smears the sea floor into a blur
					float history_cap = TEMPORAL_ACCUMULATION_MAX;
					#if HELD_LIGHT == 1
						// The held light moves with the player, but the history is locked to the world: a long history would make the light lag behind.
						history_cap = min(history_cap, mix(TEMPORAL_ACCUMULATION_MAX, 0.75, smoothstep(0.5, 6.0, held_light_luma)));
					#endif
					if(abs(material_mask_id-1.) < .5) history_cap = min(history_cap, WATER_HISTORY_MAX);
					float history_weight = min(history_cap, history_n / (history_n + 1.)) * step(0.001, ta_validity);
					lighting.rgb = mix(lighting.rgb, last_frame_hdr_color_and_TA.rgb, history_weight );
					ta_history_length = vec4(min(history_n + 1., 255.), 0., 0., 1.);
					
					//save our accumulated HDR data
					hdr_color_and_depth_non_clearing = 
						vec4( 
								RTV_CLAMP3(lighting.rgb,100000.),
								is_first_person_hand ? -distance_from_camera : distance_from_camera
							);
				#else
					color.rgb = mix(color.rgb, last_frame_hdr_color_and_TA.rgb, ta_final );
					
					//save our accumulated HDR data
					hdr_color_and_depth_non_clearing = 
						vec4( 
								RTV_CLAMP3(color.rgb,100000.),
								is_first_person_hand ? -distance_from_camera : distance_from_camera
							);
				#endif
				

			#else
				#if RT_DENOISING > 0
				//No TA, but Denoising
					
					float distance_from_camera = length(foot_pos);
					// just the lighting is saved now, not the total scene
							
					//save our accumulated HDR data
					hdr_color_and_depth_non_clearing = 
						vec4( 
								RTV_CLAMP3(lighting.rgb,100000.),
								is_first_person_hand ? -distance_from_camera : distance_from_camera
							);

				#endif
			#endif
		
		}//primary hit, this was stuff
		else{
		// Add background
			vec4 bg = texture(colortex0, texcoord) ;
			#if TONEMAPPING > 0
				bg.rgb = srgb_to_linear(bg.rgb) * (SUN_BRIGHTNESS * rtv_sky_illumination_factor());
			#endif

			color.rgb = bg.rgb;

			#if CLOUD_STYLE == 1 && !(RT_RESOLUTION_DIVIDER > 1 || RT_DENOISING > 0)
			{
				vec3 sky_view_dir;
				{
					vec3 direction_view = screen_to_view_space(vec3(texcoord, 1.));
					sky_view_dir = normalize(view_to_foot_direction(direction_view));
				}
				vec3 cloud_sun_dir = normalize(view_to_foot_direction(shadowLightPosition));
				vec4 cloud = rtv_volumetric_clouds(sky_view_dir, cloud_sun_dir, get_screen_dither().x);
				#if TONEMAPPING > 0
					color.rgb = color.rgb * cloud.a + cloud.rgb * SUN_BRIGHTNESS;
				#else
					color.rgb = color.rgb * cloud.a + linear_to_srgb(clamp(cloud.rgb * 0.62, 0.0, 1.0));
				#endif
			}
			#endif

		}
	

	#if TONEMAPPING == 1
		#if EXPOSURE == 0
			const float eyeBrightnessHalflife = 30.0;
			float exposure = mix(18.0, 30.0, clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0));
		#else
			float exposure = float(EXPOSURE);
		#endif
		float luminance = (color.r+ color.g+ color.b)/3.;
		color.rgb = color.rgb/(luminance+exposure);
		//screen gamma
		color.rgb = linear_to_srgb(color.rgb);
	#endif
	

	#if RAYTRACING_VIEW > 0
        }//> close scope of where we ignore part of the screen that are going to be full RT view
//		else{
//			color=vec4(0.);//just write black here if you want to write something, it might become garbage data if you don't, I don't know
//		}
	#endif
	
	
	//Debug Area
		//color.rgb = fract(view_dir_world.rgb*10.);
		//color.rgb = fract(foot_pos+cameraPosition);
		//color.rgb = normals_face_world;
		//color.rgb = Dither_offset;
		#if DEBUG_TA == 1
			color.rgb = mix(vec3(1.,0.,0.), vec3(1.), Debug_value.x); //TA
		#endif
}


