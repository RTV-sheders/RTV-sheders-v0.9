#version 430 compatibility

#define IS_AN_ENTITY 1
#include "/programs/shadow_v.glsl"